package SC2002_Java.MOBLIMA;

import java.util.Date;
import java.util.Scanner;

public class Price {

    private static double finalPrice;
    private String ticketType; // child, adult, senior...
    private int cinemaclass;
    private String moviestatus;
    private Date calendar_date; // get the date to check if public holiday
    private String movieType;

    // need to set prices
    private double[] agePrices = new double[3]; // childPrice, seniorPrice, normalPrice; //0 -> childPrice, 1 ->
                                                // seniorPrice, 2 -> normalPrice
    private double[] cinema_status_prices = new double[3]; // normal, premiere, gold // 0-> normal, 1-> premiere,
                                                           // 2->gold
    private double[] date_status_prices = new double[2]; // premiere, now sharing

    private double[] movie_type_prices = new double[2];

    // if blockbuster, FLAT

    public Price(Ticket tick, Cinema cine, Movie movie) {
        this.finalPrice = 0;
        this.ticketType = tick.getTicketType(); // where to go
        this.cinemaclass = cine.getType();
        this.moviestatus = Movie.getStatus();
        this.calendar_date = Calender.getdate();
        this.movieType = Movie.getType();
        agePrices = new double[] { 0, 0, 0 };
        cinema_status_prices = new double[] { 0, 0, 0 };
        date_status_prices = new double[] { 0, 0, 0 };
        movie_type_prices = new double[] { 0, 0 };

    }

    // getters and setters for admin to set child, senior, public holiday price
    public void setPrice_age(int choice) {
        Scanner sc = new Scanner(System.in);

        switch (choice) {
            case 1: // normal price
                System.out.println("Please enter price of movie ticket for adult: ");
                agePrices[2] = sc.nextDouble();
                break;
            case 2: // senior citizen price
                System.out.println("Please enter price of movie ticket for senior citizen");
                agePrices[1] = sc.nextDouble();
                break;
            case 3: // student
                System.out.println("Please enter price of movie ticket for student");
                agePrices[0] = sc.nextDouble();
                break;
        }
    }

    // based on seating arrangment
    public void setPrice_movieClass(int choice) {
        Scanner sc = new Scanner(System.in);
        switch (choice) {
            case 1: // standard
                System.out.println("Please enter rate of standard movie class: ");
                cinema_status_prices[0] = sc.nextDouble();
                break;
            case 2: // gold
                System.out.println("Please enter rate of gold movie class");
                cinema_status_prices[1] = sc.nextDouble();
                break;
            case 3: // platinum
                System.out.println("Please enter rate of platinum movie class");
                cinema_status_prices[2] = sc.nextDouble();
                break;
        }
    }

    // set price based on movie status
    public void setPrice_showStatusPrice(int choice) {
        Scanner sc = new Scanner(System.in);
        switch (choice) {
            case 1: // premiere price
                System.out.println("Please enter rate of movie premiere ");
                date_status_prices[0] = sc.nextDouble();
                break;
            case 2: // now showing
                System.out.println("Please enter rate of movie now showing");
                date_status_prices[1] = sc.nextDouble();
                break;
        }
    }

    // set price based on movie type
    public void setPrice_movieType(int choice) {
        Scanner sc = new Scanner(System.in);
        switch (choice) {
            case 1: // 2d
                System.out.println("Please enter rate of 2d movie ");
                movie_type_prices[0] = sc.nextDouble();
                break;
            case 2: // 3d
                System.out.println("Please enter rate of 3d movie");
                movie_type_prices[1] = sc.nextDouble();
                break;
        }
    }

    // BASED ON AGE: normal, student, senior citizen
    public double getChildPrice() {
        return agePrices[0];
    }

    public double getSeniorCitizenPrice() {
        return agePrices[1];
    }

    public double getNormalPrice() {
        return agePrices[2];
    }

    // BASED ON MOVIE CLASS: normal, gold, platinum
    public double get_StandardPrice() {
        return cinema_status_prices[0];
    }

    public double get_GoldPrice() {
        return cinema_status_prices[1];
    }

    public double get_PlatinumPrice() {
        return cinema_status_prices[2];
    }

    // BASED ON SHOWING STATUS: premiere, now showing
    public double get_PremierePrice() {
        return date_status_prices[0];
    }

    public double get_NowShowingPrice() {
        return date_status_prices[1];
    }

    // BASED ON MOVIE TYPE: 2d, 3d
    public double get_2DPrice() {
        return movie_type_prices[0];
    }

    public double get_3DPrice() {
        return movie_type_prices[1];
    }

    public void setFinalPrice(int ticketType) {
        double finalPrice = 0;

        double agePrice = 0; // store age price of moviegoer
        double cinemaStatusPrice = 0; // store cinema status price
        double movieStatusPrice = 0; // showing or premiere price;
        double movieTypePrice = 0; // 2d or 3d

        // check if public holiday or saturday or sunday
        if (Calender.checkPH(calendar_date) || Calender.getDayOfWeek(calendar_date) == 6
                || Calender.getDayOfWeek(calendar_date) == 1) {
            agePrice = getNormalPrice();
        } else { // normal date
            // check age
            agePrice = getNormalPrice();
            if (ticketType == 1) { // child
                agePrice = getChildPrice();
            } else if (ticketType == 2) { // senior citizen
                agePrice = getSeniorCitizenPrice();
            }
        }

        // check cinemaStatus
        cinemaStatusPrice = get_StandardPrice(); // 0 = standard = 50 (3 4 3)x5 // 1 = gold = 20 (5 5)x2 // 2 = platinum
                                                 // = 8 (2 2) x2
        if (cinemaclass == 1) {
            cinemaStatusPrice = get_GoldPrice();
        } else if (cinemaclass == 2) {
            cinemaStatusPrice = get_PlatinumPrice();
        }

        // check status of movie
        movieStatusPrice = get_NowShowingPrice();
        if (moviestatus == "Premiere") {
            movieStatusPrice = get_PremierePrice();
        }

        movieTypePrice = get_2DPrice();
        if (movieType == "3D") {
            movieTypePrice = get_3DPrice();
        }
        this.finalPrice = agePrice * cinemaStatusPrice * movieStatusPrice * movieTypePrice;

    }

    public static double getFinalPrice() {
        return finalPrice;
    }
}
