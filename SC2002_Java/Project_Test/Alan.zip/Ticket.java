package SC2002_Java.MOBLIMA;

public class Ticket {
    // private long TicketID;
    private String typeOfMovie;
    private int cinemaClass;
    private int[] showTime;
    private static int ticketType;
    private int seatID;
    private int cinemaID;
    private double ticketPrice;

    // get and set ticket type, get the price of the ticket type from price

    public Ticket(int ticketType) {
        this.typeOfMovie = Movie.getType();
        this.ticketPrice = Price.getFinalPrice();
        this.cinemaClass = Cinema.getType();
        this.showTime = Cinema.getShowtimes();
        this.ticketType = ticketType;
        this.seatID = Cinema_Seat.getSeatID();
        this.cinemaID = Cinema.getCinemaID();
    }
    // what information is needed on ticket
    // ticketType,
    // cinemaStatus
    // movieType
    // movieStatus

    public double getTicketPrice() {
        return this.ticketPrice;
    }

    public static String getTicketType() {
        if (ticketType == 1) {
            return "student";
        } else if (ticketType == 2) {
            return "senior citizen";
        } else {
            return "standard";
        }
    }

    public void setTicketType(int ticketType) {
        this.ticketType = ticketType;
    }

}
