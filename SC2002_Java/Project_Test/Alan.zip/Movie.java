package SC2002_Java.MOBLIMA;

import java.io.*;

public class Movie {
    // public enum showStatus {COMINGSOON, PREVIEW, SHOWING, ENDSHOW};

    protected String movieTitle;
    protected String Synopsis;
    protected String Director;
    protected String Casts;
    protected double Duration;
    // private showStatus Status;
    protected String Status;
    protected String Type;
    protected double totalSales;
    protected double avgRating;
    protected String Reviews;
    protected String Ratings;

    public Movie(String movieTitle, String Synopsis, String Director, String Casts,
            double Duration, String Status, String Type, double totalSales, double avgRating, String Reviews,
            String Ratings) {
        this.movieTitle = movieTitle;
        this.Synopsis = Synopsis;
        this.Director = Director;
        this.Casts = Casts;
        this.Duration = Duration;
        this.Status = Status;
        this.Type = Type;
        this.totalSales = totalSales;
        this.avgRating = avgRating;
        this.Reviews = Reviews;
        this.Ratings = Ratings;
    }

    public String getMovieTitle() {
        return movieTitle;
    }

    public String getSynopsis() {
        return Synopsis;
    }

    public String getDirector() {
        return Director;
    }

    public String getCasts() {
        return Casts;
    }

    public String getStatus() {
        return Status;
    }

    public String getType() {
        return Type;
    }

    public double getDuration() {
        return Duration;
    }

    public double gettotalSales() {
        return totalSales;
    }

    public double getavgRating() {
        return avgRating;
    }

    public double calculateAvgRating(String numberList) {
        String[] splitArray = numberList.split(",");
        int n = splitArray.length;
        int[] numArray = new int[n];

        int sum = 0;
        for (int i = 0; i < n; i++) {
            sum += Integer.parseInt(splitArray[i]);
        }

        return (double) (sum / n);
    }

    public String getReviews() {
        return Reviews;
    }

    public String getRatings() {
        return Ratings;
    }

    public void Create() throws IOException {
        String fileName = "SC2002_Java/MOBLIMA/MovieList.txt";
        FileWriter fstream = new FileWriter(fileName, true);
        BufferedWriter out = new BufferedWriter(fstream);

        String append = movieTitle + "|" + Synopsis + "|" + Director + "|" + Casts + "|" + Status + "|" +
                Type + "|" + Duration + "|" + totalSales + "|" + avgRating + "|" + Reviews + "|" + Ratings;
        out.write(append);
        out.newLine();

        // close buffer writer
        out.close();

        System.out.println("Added new movie");
    }

    public void display() {
        System.out.println(movieTitle + " " + Status + "\n"
                + "Synopsis: " + Synopsis + "\n"
                + "Director: " + Director + "\n"
                + "Casts: " + Casts + "\n"
                + "Duration/Running Time: " + Duration + "\n"
                + "Status: " + Status + "\n"
                + "Type: " + Type + "\n"
                + "Total Sales: " + totalSales + "\n"
                + "Reviews: " + Duration + "\n"
                + "Ratings: " + Ratings + "\n");
    }
}
