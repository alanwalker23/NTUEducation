package SC2002_Java.MOBLIMA;

import java.util.Calendar;
import java.util.Scanner;

public class TransactionBooking<Person> {
    private static int numTickets = 0;
    private String cineplexLocation;
    private int cinemaID;
    private double totalBookingPrice;
    private Movie_Goer bookingPerson;
    private Ticket[] ticket = new Ticket[10];

    public TransactionBooking() {

    }
    public TransactionBooking(Cineplex cineplex, Cinema cine) {
        this.cineplexLocation = cineplex.getLocation();
        this.cinemaID = cine.getCinemaID();
        this.totalBookingPrice = 0;
        // this.bookingPerson = new Movie_Goer();
    }

    public String getTransactionID() {
        // Each payment will have a transaction id (TID). The TID is of the
        // format XXX YYYY MM DD hh mm (Y : year, M : month, D : day, h : hour, m :
        // minutes, XXX : cinema code in letters).
        // havent set YEAR MONTH HOUR MINUTE
        String getID = cineplexLocation + cinemaID
                + String.format("%4d%02d%02d%02d", Calendar.YEAR, Calendar.MONTH, Calendar.HOUR, Calendar.MINUTE);

        return getID;
    }
    // when the

    public void settotalBookingPrice(Ticket[] ticket) {

        for (int j = 0; j < 10; j++) {
            totalBookingPrice += ticket[j].getTicketPrice();
        }
    }

    public double getTotalBookingPrice() {
        return totalBookingPrice;
    }

    public void createTicket() {

        System.out.println("Select ticketType: (1) Student (2) Senior Citizen (3) Standard: ");
        Scanner sc = new Scanner(System.in);
        int ticketType = sc.nextInt();
        ticket[numTickets] = new Ticket(ticketType);
        numTickets++;
    }

}
